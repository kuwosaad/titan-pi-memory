from __future__ import annotations

import math
import re
from collections import Counter
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Sequence, Tuple

import networkx as nx
import numpy as np
from networkx.algorithms.community import greedy_modularity_communities

from app.graph.builder import DEFAULT_GRAPH_MEMORY_LIMIT, load_memories, load_visual_config
from app.graph.corpus_analysis import CorpusAnalysis, snapshot_for_memories
from app.storage.memories import get_memory_count


MIN_SIMILARITY = 0.35
DEFAULT_DETAIL_LIMIT = 12
# The browser graph intentionally stays capped elsewhere for UI performance, but
# cluster inspection/dashboard should be able to analyze the full memory store.
# Keep a high safety cap so accidental huge requests do not allocate an
# unbounded pairwise similarity matrix.
MAX_CLUSTER_MEMORY_LIMIT = 10000
_MAX_TOPIC_TERMS = 4
_CACHE: dict[tuple[Any, ...], dict[str, Any]] = {}

_STOPWORDS = {
    "about", "above", "after", "again", "against", "being", "because", "before", "between",
    "both", "cannot", "could", "during", "each", "from", "have", "having", "into", "itself",
    "just", "more", "most", "must", "only", "other", "over", "same", "should", "than", "that",
    "their", "there", "these", "this", "those", "through", "under", "using", "very", "when",
    "where", "which", "while", "with", "within", "without", "would", "your", "will", "were",
    "been", "they", "them", "then", "also", "such", "like", "make", "made", "makes", "needs",
    "need", "used", "uses", "use", "currently", "current", "previous", "recent", "memory",
    "memories", "system", "project", "package", "extension", "updated", "asked", "titan",
}

_TOKEN_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9_./-]{2,}")


def _memory_dict(memory: Any) -> Dict[str, Any]:
    return memory.model_dump() if hasattr(memory, "model_dump") else dict(memory)


def _clean_token(token: str) -> str:
    token = token.lower().strip("`'\".,:;!?()[]{}<>")
    token = token.replace("’s", "").replace("'s", "")
    return token


def _tokens(text: str) -> List[str]:
    result: List[str] = []
    for raw in _TOKEN_RE.findall(text or ""):
        token = _clean_token(raw)
        if len(token) < 3 or token in _STOPWORDS:
            continue
        if token.isdigit():
            continue
        result.append(token)
    return result


def _document_frequencies(memories: Sequence[Dict[str, Any]]) -> Counter[str]:
    df: Counter[str] = Counter()
    for mem in memories:
        df.update(set(_tokens(str(mem.get("text") or ""))))
    return df


def _build_similarity_edges(vectors: Sequence[np.ndarray], top_k: int, min_sim: float) -> List[Tuple[int, int, float]]:
    # Keep this helper as a compatibility patch point. The actual calculation
    # is delegated to the shared bounded snapshot so callers never allocate an
    # n x n similarity matrix.
    return snapshot_for_memories(
        [{"embedding": np.asarray(vector, dtype=np.float32).tolist()} for vector in vectors]
    ).top_k_edges(top_k=top_k, min_sim=min_sim)


def _cluster_keywords(
    cluster_memories: Sequence[Dict[str, Any]],
    all_count: int,
    doc_freq: Counter[str],
) -> List[str]:
    counts: Counter[str] = Counter()
    for mem in cluster_memories:
        counts.update(_tokens(str(mem.get("text") or "")))

    scored: List[Tuple[str, float]] = []
    for token, count in counts.items():
        df = max(1, doc_freq.get(token, 1))
        idf = math.log((all_count + 1) / df)
        shape_bonus = 1.25 if any(ch in token for ch in "-_/.") else 1.0
        scored.append((token, float(count) * idf * shape_bonus))

    scored.sort(key=lambda item: (-item[1], item[0]))
    return [token for token, _score in scored[:10]]


def _topic_from_keywords(keywords: Sequence[str], types: Counter[str]) -> str:
    if keywords:
        return " / ".join(keywords[:_MAX_TOPIC_TERMS])
    if types:
        return " / ".join(kind for kind, _count in types.most_common(3))
    return "miscellaneous memories"


def _shorten(text: str, limit: int = 220) -> str:
    text = " ".join(str(text or "").split())
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def _timestamp_sort_key(memory: Dict[str, Any]) -> tuple[datetime, str]:
    value = memory.get("ts")
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        parsed = datetime.min.replace(tzinfo=timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc), str(memory.get("id") or "")


def _cache_key(session_id: Optional[str], limit: int, memories: Sequence[Dict[str, Any]]) -> tuple[Any, ...]:
    # The revision is content/embedding based; LNN activation-only updates do
    # not invalidate graph structure, while edits to text or embeddings do.
    snapshot = snapshot_for_memories(memories)
    return (session_id or "", int(limit), snapshot.revision)


def resolve_cluster_memory_limit(limit: Optional[int], total_memory_count: int) -> int:
    """Resolve the cluster analysis memory window.

    A limit of 0 or less means "analyze all memories". Positive limits still
    mean "analyze the N most recent memories". This lets dashboards use the full
    corpus while the browser graph can remain independently capped.
    """
    if limit is None or int(limit) <= 0:
        return min(max(0, int(total_memory_count)), MAX_CLUSTER_MEMORY_LIMIT)
    return max(1, min(int(limit), MAX_CLUSTER_MEMORY_LIMIT))


def inspect_memory_clusters(
    session_id: Optional[str] = None,
    limit: int = DEFAULT_GRAPH_MEMORY_LIMIT,
    cluster_id: Optional[int] = None,
    detail_limit: int = DEFAULT_DETAIL_LIMIT,
    corpus: Optional[CorpusAnalysis] = None,
) -> Dict[str, Any]:
    """Return fast, deterministic topic summaries for the graph communities."""
    if corpus is not None:
        # An explicit corpus is an immutable caller-owned analysis boundary.
        # Do not reload the database here: doing so both defeats bounded
        # snapshots and makes the cache key independent of the supplied data.
        source_memories = list(corpus.source_memories or corpus.memories)
        total_memory_count = len(source_memories)
        safe_limit = resolve_cluster_memory_limit(limit, total_memory_count)
        raw_memories = source_memories
        if safe_limit < len(source_memories):
            raw_memories = sorted(
                source_memories,
                key=_timestamp_sort_key,
                reverse=True,
            )[:safe_limit]
            corpus = snapshot_for_memories(raw_memories)
    else:
        total_memory_count = get_memory_count(session_id=session_id)
        raw_memories = [_memory_dict(mem) for mem in load_memories(session_id=session_id, limit=resolve_cluster_memory_limit(limit, total_memory_count))]
    safe_limit = resolve_cluster_memory_limit(limit, total_memory_count)
    detail_limit = max(1, min(int(detail_limit or DEFAULT_DETAIL_LIMIT), 50))

    key = _cache_key(session_id, safe_limit, raw_memories)
    if key in _CACHE:
        payload = _CACHE[key]
    else:
        corpus = corpus or snapshot_for_memories(raw_memories)
        indexed_memories = list(corpus.memories)
        vectors: List[np.ndarray] = [row for row in corpus.vectors]
        skipped_missing_embeddings = max(0, len(raw_memories) - len(indexed_memories))

        config = load_visual_config()
        top_k = int(config.get("physics", {}).get("forces", {}).get("link", {}).get("iterations", 2) or 2)
        # The snapshot owns normalization and sparse blockwise cosine edges.
        # Keep ``_build_similarity_edges`` above as a compatibility forwarding
        # helper for external callers and tests.
        edges = corpus.top_k_edges(top_k=top_k, min_sim=MIN_SIMILARITY)

        graph = nx.Graph()
        graph.add_nodes_from(range(len(indexed_memories)))
        for a, b, weight in edges:
            graph.add_edge(a, b, weight=weight)

        if graph.number_of_edges() > 0:
            communities = list(greedy_modularity_communities(graph))
        else:
            communities = [frozenset([idx]) for idx in range(len(indexed_memories))]

        doc_freq = _document_frequencies(indexed_memories)
        cluster_records: List[Dict[str, Any]] = []
        for idx, community in enumerate(communities, start=1):
            member_indices = sorted(int(node) for node in community)
            cluster_memories = [indexed_memories[node] for node in member_indices]
            subgraph = graph.subgraph(member_indices)
            degrees = dict(subgraph.degree())
            representative_indices = sorted(
                member_indices,
                key=lambda node: (-degrees.get(node, 0), *_timestamp_sort_key(indexed_memories[node])),
            )[:detail_limit]
            weights = [float(data.get("weight", 0.0)) for _u, _v, data in subgraph.edges(data=True)]
            types: Counter[str] = Counter(str(mem.get("type") or "memory") for mem in cluster_memories)
            streams: Counter[str] = Counter(str(mem.get("stream") or "rough") for mem in cluster_memories)
            sessions = {str(mem.get("session_id") or "") for mem in cluster_memories if mem.get("session_id")}
            keywords = _cluster_keywords(cluster_memories, len(indexed_memories), doc_freq)
            topic = _topic_from_keywords(keywords, types)
            examples = [
                {
                    "id": mem.get("id"),
                    "text": _shorten(str(mem.get("text") or "")),
                    "type": mem.get("type") or "memory",
                    "stream": mem.get("stream") or "rough",
                    "session_id": mem.get("session_id"),
                    "scene_id": mem.get("scene_id"),
                    "ts": mem.get("ts"),
                    "turn": mem.get("turn"),
                }
                for mem in (indexed_memories[node] for node in representative_indices)
            ]

            cluster_records.append(
                {
                    "cluster_id": idx,
                    "topic": topic,
                    "keywords": keywords,
                    "memory_count": len(member_indices),
                    "connection_count": subgraph.number_of_edges(),
                    "avg_similarity": round(sum(weights) / len(weights), 3) if weights else 0.0,
                    "types": dict(types.most_common()),
                    "streams": dict(streams.most_common()),
                    "session_count": len(sessions),
                    "examples": examples,
                    "memory_ids": [indexed_memories[node].get("id") for node in member_indices],
                }
            )

        cluster_records.sort(key=lambda rec: (-int(rec["memory_count"]), int(rec["cluster_id"])))
        payload = {
            "scope": "session" if session_id else "global",
            "session_id": session_id,
            "total_memory_count": total_memory_count,
            "memory_count": len(indexed_memories),
            "raw_memory_count": len(raw_memories),
            "skipped_missing_embeddings": skipped_missing_embeddings,
            "connection_count": len(edges),
            "cluster_count": len(cluster_records),
            "clusters": cluster_records,
            "limit": safe_limit,
            "limited": safe_limit < total_memory_count,
            "max_cluster_memory_limit": MAX_CLUSTER_MEMORY_LIMIT,
        }
        _CACHE.clear()
        _CACHE[key] = payload

    if cluster_id is not None:
        match = next((cluster for cluster in payload["clusters"] if int(cluster["cluster_id"]) == int(cluster_id)), None)
        if not match:
            return {**payload, "error": f"cluster {cluster_id} not found"}
        return {**payload, "selected_cluster": match}

    return payload
