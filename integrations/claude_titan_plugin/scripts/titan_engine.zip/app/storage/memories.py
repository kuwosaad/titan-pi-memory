from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any, ContextManager, Dict, List, Optional, Tuple

import numpy as np

from .models import Memory
from .repository import CandidateFilters, MemoryStore
from .sessions import BASE_DIR, MEMORIES_DIR, read_json, write_json
from . import sessions as _sessions
from .sqlite import sqlite_connection
from .sqlite_schema import ensure_memory_readable_views, ensure_memory_store_metadata, ensure_pattern_tables


LOGGER = logging.getLogger(__name__)
MEMORIES_FILE = MEMORIES_DIR / "memories.json"
DEFAULT_SQLITE_FILE = MEMORIES_DIR / "memory_store.db"
_MEMORY_ROOT = MEMORIES_DIR
SQLITE_TIMEOUT_SECONDS = 30.0
_MEMORIES_LOCK = threading.RLock()
_REPO_CACHE: Optional[MemoryStore] = None
_REPO_CACHE_KEY: Optional[Tuple[str, str]] = None
# Stable production-resolver marker.  Federation uses this rather than
# comparing module attributes, which can both point at a test double when
# federation is imported while this module is patched.
_REAL_GET_MEMORY_REPOSITORY = None
_ALLOWED_MEMORY_KINDS = {
    "user_fact",
    "user_preference",
    "task",
    "decision",
    "commitment",
    "outcome",
    "relationship",
    "workflow",
    "issue",
}
_RETRIEVAL_REPOSITORY_KEY = "_retrieval_repository"
_MEMORY_OPTIONAL_FIELDS = (
    "event_date", "event_start", "event_end", "subject", "scope", "attribute",
    "correction_target", "correction_evidence",
)


def _refresh_json_paths() -> None:
    """Keep the compatibility JSON adapter aligned with the active context."""

    global MEMORIES_FILE, DEFAULT_SQLITE_FILE, _MEMORY_ROOT
    _sessions.refresh_runtime_paths()
    current_root = _sessions.MEMORIES_DIR
    if current_root == _MEMORY_ROOT:
        return
    if MEMORIES_FILE == _MEMORY_ROOT / "memories.json":
        MEMORIES_FILE = current_root / "memories.json"
    if DEFAULT_SQLITE_FILE == _MEMORY_ROOT / "memory_store.db":
        DEFAULT_SQLITE_FILE = current_root / "memory_store.db"
    _MEMORY_ROOT = current_root
_ALLOWED_SPEAKER_FOCUS = {"user", "assistant", "shared", "system"}
_LEGACY_SPEAKER_FOCUS_ALIASES = {
    "mixed": "shared",
    "both": "shared",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def pack_embedding(vec: Any) -> Tuple[Optional[bytes], Optional[int], Optional[str]]:
    if vec is None:
        return None, None, None
    array = np.asarray(vec, dtype=np.float32).reshape(-1)
    if array.size == 0:
        return None, None, None
    return np.ascontiguousarray(array).tobytes(), int(array.size), "f32"


def unpack_embedding(blob: Optional[bytes], dim: Optional[int], dtype: Optional[str]) -> Optional[np.ndarray]:
    if not blob or not dim:
        return None
    if dtype not in (None, "f32"):
        raise ValueError(f"Unsupported embedding dtype: {dtype}")
    array = np.frombuffer(blob, dtype=np.float32, count=int(dim))
    if array.size != int(dim):
        raise ValueError("Embedding size mismatch while decoding blob")
    return array


def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _normalize_memory_kind(mem: Dict[str, Any]) -> Optional[str]:
    raw_kind = mem.get("memory_kind")
    if raw_kind is None:
        return None

    kind = str(raw_kind).strip().lower()
    if not kind:
        return None
    if kind in _ALLOWED_MEMORY_KINDS:
        return kind

    from app.save_pipeline.extraction.extractor import classify_memory

    _speaker_focus, normalized_kind = classify_memory(str(mem.get("text") or ""), mem.get("type"))
    LOGGER.info("Normalizing legacy memory_kind '%s' -> '%s' for memory id=%s", kind, normalized_kind, mem.get("id"))
    return normalized_kind if normalized_kind in _ALLOWED_MEMORY_KINDS else None


def _normalize_speaker_focus(value: Any) -> Optional[str]:
    if value is None:
        return None
    speaker_focus = str(value).strip().lower()
    if not speaker_focus:
        return None
    speaker_focus = _LEGACY_SPEAKER_FOCUS_ALIASES.get(speaker_focus, speaker_focus)
    return speaker_focus if speaker_focus in _ALLOWED_SPEAKER_FOCUS else None


def _normalize_memory(mem: Dict[str, Any]) -> Dict[str, Any]:
    normalized = dict(mem)
    for field in _MEMORY_OPTIONAL_FIELDS:
        value = normalized.get(field)
        normalized[field] = str(value).strip() or None if value is not None else None
    if normalized.get("source_agent") is not None:
        normalized["source_agent"] = str(normalized["source_agent"])
    normalized.setdefault("stream", "rough")
    normalized.setdefault("scene_id", None)
    normalized.setdefault("source_event_ids", [])
    if not normalized.get("source_type"):
        normalized["source_type"] = "legacy"
    if normalized.get("source_reliability") is None:
        normalized["source_reliability"] = 0.3
    normalized.setdefault("verification_status", "unverified")
    normalized.setdefault("fallback_generated", False)
    normalized["speaker_focus"] = _normalize_speaker_focus(normalized.get("speaker_focus"))
    normalized["memory_kind"] = _normalize_memory_kind(normalized)
    provenance = normalized.get("provenance")
    if not isinstance(provenance, dict):
        normalized["provenance"] = {"user": "", "assistant": ""}
    else:
        normalized["provenance"] = {
            "user": str(provenance.get("user") or ""),
            "assistant": str(provenance.get("assistant") or ""),
        }
    return normalized


def _normalize_stream(value: Any) -> str:
    stream = str(value or "rough").strip().lower()
    return stream if stream in {"rough", "learnings"} else "rough"


_MEMORY_IDENTITY_FIELDS = (
    "id",
    "text",
    "type",
    "stream",
    "session_id",
    "turn",
    "scene_id",
    "source_type",
    "source_reliability",
    "verification_status",
    "fallback_generated",
    "source_event_ids",
    "provenance",
    "speaker_focus",
    "memory_kind",
    *_MEMORY_OPTIONAL_FIELDS,
    "embedding",
)


def _canonical_memory_payload(record: Dict[str, Any]) -> str:
    """Return immutable derivation identity, excluding mutable retrieval state."""

    normalized = _normalize_memory(record)
    payload = {field: normalized.get(field) for field in _MEMORY_IDENTITY_FIELDS}
    payload["id"] = str(normalized.get("id") or "")
    payload["text"] = str(normalized.get("text") or "")
    payload["stream"] = _normalize_stream(normalized.get("stream"))
    payload["session_id"] = str(normalized.get("session_id") or "")
    payload["turn"] = int(normalized.get("turn") or 0)
    payload["scene_id"] = (
        str(normalized["scene_id"]) if normalized.get("scene_id") is not None else None
    )
    payload["source_type"] = str(normalized.get("source_type") or "legacy")
    payload["source_reliability"] = float(normalized.get("source_reliability") or 0.0)
    payload["verification_status"] = str(normalized.get("verification_status") or "unverified")
    payload["fallback_generated"] = bool(normalized.get("fallback_generated", False))
    payload["source_event_ids"] = [str(value) for value in normalized.get("source_event_ids") or []]
    payload["speaker_focus"] = normalized.get("speaker_focus")
    payload["memory_kind"] = normalized.get("memory_kind")

    embedding = normalized.get("embedding")
    if embedding is None:
        payload["embedding"] = None
    else:
        array = np.asarray(embedding, dtype=np.float32).reshape(-1)
        payload["embedding"] = array.tolist() if array.size else None
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def _same_memory(left: Dict[str, Any], right: Dict[str, Any]) -> bool:
    return _canonical_memory_payload(left) == _canonical_memory_payload(right)


def _exact_evidence_key(record: Dict[str, Any]) -> Optional[str]:
    """Identify an exact claim retry only when durable evidence is addressed.

    A fresh turn/id or regenerated embedding does not create new evidence.
    Different scenes, event lineage, provenance or claim metadata still do.
    Records without scene/event identity cannot safely be deduplicated by text.
    Repository boundaries provide the agent namespace; session stays in the key.
    """

    if not record.get("scene_id") and not record.get("source_event_ids"):
        return None
    payload = json.loads(_canonical_memory_payload({**record, "embedding": None}))
    for field in ("id", "turn", "embedding"):
        payload.pop(field)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _memory_id(record: Dict[str, Any]) -> str:
    return str(record.get("id") or "")


def _reject_memory_collision(memory_id: str) -> None:
    LOGGER.warning("Rejecting immutable Memory collision for memory_id=%s", memory_id)
    raise ValueError(f"memory collision for immutable memory id: {memory_id}")


def _resolve_sqlite_path() -> Path:
    from app.runtime.context import get_runtime_context
    return get_runtime_context().memory_db_path


def _resolve_backend() -> str:
    from app.runtime.context import get_runtime_context
    return get_runtime_context().memory_backend


def _resolve_read_fallback() -> str:
    from app.runtime.context import get_runtime_context
    return get_runtime_context().read_fallback


def _is_database_locked_error(exc: Exception) -> bool:
    return isinstance(exc, sqlite3.OperationalError) and "database is locked" in str(exc).lower()


class JsonMemoryRepository:
    """Legacy JSON adapter for basic MemoryStore operations."""

    def __init__(self, memories_file: Optional[Path] = None) -> None:
        # The optional path is an internal seam for isolated namespace reads.
        # The legacy module-level path remains the default for compatibility.
        self.memories_file = memories_file

    @property
    def _path(self) -> Path:
        return self.memories_file or MEMORIES_FILE

    def load_all_memories(self) -> List[Dict[str, Any]]:
        with _MEMORIES_LOCK:
            return [_normalize_memory(mem) for mem in read_json(self._path, [])]

    def save_all_memories(self, memories: List[Dict[str, Any]]) -> None:
        with _MEMORIES_LOCK:
            write_json(self._path, memories)

    def append_memories(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not records:
            return []
        with _MEMORIES_LOCK:
            all_memories = read_json(self._path, [])
            # Do not repair or rewrite historical duplicate IDs here. A legacy
            # JSON store may contain duplicate rows with distinct mutable LNN
            # metadata; append must preserve every existing row verbatim.
            existing_by_id: Dict[str, List[Dict[str, Any]]] = {}
            for item in all_memories:
                if isinstance(item, dict):
                    memory_id = _memory_id(item)
                    if memory_id:
                        existing_by_id.setdefault(memory_id, []).append(item)

            retained: List[Any] = list(all_memories)
            evidence_records = {}
            for item in all_memories:
                if isinstance(item, dict) and (key := _exact_evidence_key(item)) is not None:
                    evidence_records.setdefault(key, item)
            accepted = []
            canonical_by_input_id = {}
            changed = False
            for record in records:
                if not isinstance(record, dict):
                    retained.append(record)
                    accepted.append(record)
                    changed = True
                    continue
                memory_id = _memory_id(record)
                existing = existing_by_id.get(memory_id, []) if memory_id else []
                if existing:
                    matching = next((item for item in existing if _same_memory(item, record)), None)
                    if matching is not None:
                        accepted.append(_normalize_memory(canonical_by_input_id.get(memory_id, matching)))
                        continue
                    _reject_memory_collision(memory_id)
                if memory_id:
                    existing_by_id[memory_id] = [record]
                evidence_key = _exact_evidence_key(record)
                if evidence_key is not None:
                    if evidence_key in evidence_records:
                        canonical = evidence_records[evidence_key]
                        if memory_id:
                            canonical_by_input_id[memory_id] = canonical
                        accepted.append(_normalize_memory(canonical))
                        continue
                    evidence_records[evidence_key] = record
                retained.append(record)
                accepted.append(_normalize_memory(record))
                changed = True

            if changed:
                write_json(self._path, retained)
        return accepted

    def get_recent_memories(self, limit: Optional[int] = 8, session_id: Optional[str] = None) -> List[Dict[str, Any]]:
        all_memories = self.load_all_memories()
        if session_id:
            all_memories = [mem for mem in all_memories if mem.get("session_id") == session_id]
        # ``None`` is the explicit unlimited form used by corpus analysis.
        # Keep the historical positive-integer behavior unchanged.
        sliced = all_memories if limit is None else all_memories[-int(limit):]
        return list(reversed(sliced))

    def get_memory_count(self, session_id: Optional[str] = None) -> int:
        all_memories = self.load_all_memories()
        if session_id:
            all_memories = [mem for mem in all_memories if mem.get("session_id") == session_id]
        return len(all_memories)

    def list_memory_session_ids(self, limit: int = 100) -> List[str]:
        all_memories = self.load_all_memories()
        seen: set[str] = set()
        result: list[str] = []
        for mem in all_memories:
            sid = mem.get("session_id")
            if sid and sid not in seen:
                seen.add(sid)
                result.append(sid)
                if len(result) >= limit:
                    break
        return result

    def query_candidates_with_text(self, fts_query: str, filters: CandidateFilters) -> List[Dict[str, Any]]:
        return self.query_candidates(filters)

    def query_candidates(self, filters: CandidateFilters) -> List[Dict[str, Any]]:
        memories = self.load_all_memories()
        if filters.recency_days:
            cutoff = datetime.now(timezone.utc) - timedelta(days=filters.recency_days)
            memories = [mem for mem in memories if (_parse_timestamp(mem.get("ts")) or cutoff) >= cutoff]

        if filters.date_from:
            date_from_dt = _parse_timestamp(filters.date_from)
            if date_from_dt:
                memories = [
                    mem for mem in memories
                    if (mem_ts := _parse_timestamp(mem.get("ts"))) is not None
                    and mem_ts >= date_from_dt
                ]

        if filters.date_to:
            date_to_dt = _parse_timestamp(filters.date_to)
            if date_to_dt:
                memories = [
                    mem for mem in memories
                    if (mem_ts := _parse_timestamp(mem.get("ts"))) is not None
                    and mem_ts <= date_to_dt
                ]

        if filters.memory_types:
            allowed = {item.lower() for item in filters.memory_types}
            memories = [mem for mem in memories if str(mem.get("type", "")).lower() in allowed]

        if filters.mode in {"rough", "learnings"}:
            memories = [mem for mem in memories if str(mem.get("stream", "rough")) == filters.mode]

        memories = [mem for mem in memories if float(mem.get("source_reliability", 0.0)) >= filters.min_reliability]

        if filters.session_id and filters.session_bias:
            session_memories = [mem for mem in memories if mem.get("session_id") == filters.session_id]
            if session_memories:
                memories = session_memories
        return memories

    def query_by_ids(self, memory_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        memories = self.load_all_memories()
        by_id = {mem["id"]: mem for mem in memories if mem.get("id") in set(memory_ids)}
        return by_id

class SqliteMemoryRepository:
    """SQLite memory adapter; LNN state remains readable as stored fields."""
    def __init__(self, db_path: Path, *, initialize: bool = True) -> None:
        self.db_path = db_path
        # Federation constructs this adapter with ``initialize=False`` for
        # read-only inspection.  Do not materialize a missing namespace just
        # by constructing its adapter.
        if initialize:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._read_only = not initialize
        self._lock = threading.RLock()
        if initialize:
            self._init_schema()

    def _connect(self) -> ContextManager[sqlite3.Connection]:
        return sqlite_connection(self.db_path, read_only=self._read_only)

    def _init_schema(self) -> None:
        ddl = """
        CREATE TABLE IF NOT EXISTS memories (
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            turn INTEGER NOT NULL,
            scene_id TEXT,
            idx INTEGER NOT NULL,
            text TEXT NOT NULL,
            type TEXT,
            stream TEXT NOT NULL CHECK(stream IN ('rough','learnings')),
            ts TEXT NOT NULL,
            source_type TEXT NOT NULL,
            source_reliability REAL NOT NULL,
            verification_status TEXT NOT NULL,
            fallback_generated INTEGER NOT NULL,
            source_event_ids_json TEXT NOT NULL,
            provenance_user TEXT NOT NULL,
            provenance_assistant TEXT NOT NULL,
            speaker_focus TEXT,
            memory_kind TEXT,
            event_date TEXT,
            event_start TEXT,
            event_end TEXT,
            subject TEXT,
            scope TEXT,
            attribute TEXT,
            correction_target TEXT,
            correction_evidence TEXT,
            embedding_blob BLOB,
            embedding_dim INTEGER,
            embedding_dtype TEXT CHECK(embedding_dtype IN ('f32') OR embedding_dtype IS NULL),
            h REAL NOT NULL DEFAULT 0.0,
            tau REAL NOT NULL DEFAULT 0.5,
            outgoing_weights BLOB,
            incoming_weights BLOB
        );
        CREATE INDEX IF NOT EXISTS idx_memories_session_ts ON memories(session_id, ts DESC);
        CREATE INDEX IF NOT EXISTS idx_memories_scene_id ON memories(scene_id);
        CREATE INDEX IF NOT EXISTS idx_memories_stream_ts ON memories(stream, ts DESC);
        CREATE INDEX IF NOT EXISTS idx_memories_type_ts ON memories(type, ts DESC);
        CREATE INDEX IF NOT EXISTS idx_memories_reliability ON memories(source_reliability);
        CREATE INDEX IF NOT EXISTS idx_memories_ts ON memories(ts DESC);

        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            text,
            content='memories',
            content_rowid='rowid',
            tokenize='porter unicode61 remove_diacritics 2'
        );

        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, text) VALUES (new.rowid, new.text);
        END;

        CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, text) VALUES('delete', old.rowid, old.text);
        END;

        DROP TRIGGER IF EXISTS memories_au;
        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE OF text ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, text) VALUES('delete', old.rowid, old.text);
            INSERT INTO memories_fts(rowid, text) VALUES (new.rowid, new.text);
        END;
        """
        with self._lock, self._connect() as conn:
            conn.executescript(ddl)
            existing_columns = {row["name"] for row in conn.execute("PRAGMA table_info(memories)").fetchall()}
            if "scene_id" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN scene_id TEXT")
            if "speaker_focus" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN speaker_focus TEXT")
            if "memory_kind" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN memory_kind TEXT")
            for field in _MEMORY_OPTIONAL_FIELDS:
                if field not in existing_columns:
                    conn.execute(f"ALTER TABLE memories ADD COLUMN {field} TEXT")
            if "h" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN h REAL NOT NULL DEFAULT 0.0")
            if "tau" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN tau REAL NOT NULL DEFAULT 0.5")
            if "outgoing_weights" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN outgoing_weights BLOB")
            if "incoming_weights" not in existing_columns:
                conn.execute("ALTER TABLE memories ADD COLUMN incoming_weights BLOB")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_scene_id ON memories(scene_id)")
            ensure_memory_store_metadata(conn)
            ensure_pattern_tables(conn)
            fts_count = conn.execute("SELECT COUNT(*) AS c FROM memories_fts").fetchone()["c"]
            mem_count = conn.execute("SELECT COUNT(*) AS c FROM memories").fetchone()["c"]
            if mem_count > 0:
                try:
                    conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('integrity-check')")
                    if fts_count == 0:
                        conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
                except sqlite3.DatabaseError:
                    conn.execute("INSERT INTO memories_fts(memories_fts) VALUES('rebuild')")
            conn.commit()
            ensure_memory_readable_views(conn)
            conn.commit()

    def _record_to_row(self, record: Dict[str, Any]) -> Dict[str, Any]:
        normalized = _normalize_memory(record)
        idx = int(str(normalized.get("id", "0:0:0")).split(":")[-1] or 0)
        blob, dim, dtype = pack_embedding(normalized.get("embedding"))
        source_reliability = normalized.get("source_reliability")
        if source_reliability is None:
            source_reliability = 0.5
        outgoing_weights = normalized.get("outgoing_weights")
        incoming_weights = normalized.get("incoming_weights")
        outgoing_blob = json.dumps(outgoing_weights).encode() if isinstance(outgoing_weights, dict) else None
        incoming_blob = json.dumps(incoming_weights).encode() if isinstance(incoming_weights, dict) else None
        return {
            "id": str(normalized.get("id")),
            "session_id": str(normalized.get("session_id")),
            "turn": int(normalized.get("turn", 0)),
            "scene_id": normalized.get("scene_id"),
            "idx": idx,
            "text": str(normalized.get("text", "")),
            "type": normalized.get("type"),
            "stream": _normalize_stream(normalized.get("stream")),
            "ts": str(normalized.get("ts") or now_iso()),
            "source_type": str(normalized.get("source_type", "unknown")),
            "source_reliability": float(source_reliability),
            "verification_status": str(normalized.get("verification_status", "unverified")),
            "fallback_generated": 1 if bool(normalized.get("fallback_generated", False)) else 0,
            "source_event_ids_json": json.dumps(list(normalized.get("source_event_ids", []))),
            "provenance_user": str((normalized.get("provenance") or {}).get("user", "")),
            "provenance_assistant": str((normalized.get("provenance") or {}).get("assistant", "")),
            "speaker_focus": normalized.get("speaker_focus"),
            "memory_kind": normalized.get("memory_kind"),
            **{field: normalized.get(field) for field in _MEMORY_OPTIONAL_FIELDS},
            "h": float(normalized.get("h", 0.0)),
            "tau": float(normalized.get("tau", 0.5)),
            "outgoing_weights": outgoing_blob,
            "incoming_weights": incoming_blob,
            "embedding_blob": blob,
            "embedding_dim": dim,
            "embedding_dtype": dtype,
        }

    def _row_to_memory(self, row: sqlite3.Row, decode_embedding: bool, include_blob: bool = False) -> Dict[str, Any]:
        memory: Dict[str, Any] = {
            "id": row["id"],
            "text": row["text"],
            "type": row["type"],
            "stream": row["stream"],
            "ts": row["ts"],
            "session_id": row["session_id"],
            "turn": row["turn"],
            "scene_id": row["scene_id"] if "scene_id" in row.keys() else None,
            "provenance": {
                "user": row["provenance_user"] or "",
                "assistant": row["provenance_assistant"] or "",
            },
            "source_event_ids": json.loads(row["source_event_ids_json"] or "[]"),
            "source_type": row["source_type"],
            "source_reliability": float(row["source_reliability"]),
            "verification_status": row["verification_status"],
            "fallback_generated": bool(row["fallback_generated"]),
            "speaker_focus": row["speaker_focus"] if "speaker_focus" in row.keys() else None,
            "memory_kind": row["memory_kind"] if "memory_kind" in row.keys() else None,
            **{field: row[field] if field in row.keys() else None for field in _MEMORY_OPTIONAL_FIELDS},
            "h": float(row["h"]) if "h" in row.keys() else 0.0,
            "tau": float(row["tau"]) if "tau" in row.keys() else 0.5,
            "embedding": None,
        }
        memory["memory_kind"] = _normalize_memory_kind(memory)

        outgoing_blob = row["outgoing_weights"] if "outgoing_weights" in row.keys() else None
        incoming_blob = row["incoming_weights"] if "incoming_weights" in row.keys() else None
        if outgoing_blob:
            try:
                memory["outgoing_weights"] = json.loads(outgoing_blob)
            except (json.JSONDecodeError, TypeError):
                memory["outgoing_weights"] = None
        if incoming_blob:
            try:
                memory["incoming_weights"] = json.loads(incoming_blob)
            except (json.JSONDecodeError, TypeError):
                memory["incoming_weights"] = None

        blob = row["embedding_blob"]
        dim = row["embedding_dim"]
        dtype = row["embedding_dtype"]
        if decode_embedding and blob and dim:
            try:
                vector = unpack_embedding(blob, int(dim), dtype)
                memory["embedding"] = vector.tolist() if vector is not None else None
            except ValueError:
                LOGGER.warning("Failed to decode embedding blob for memory id=%s", row["id"])

        if include_blob:
            memory["_embedding_blob"] = blob
            memory["_embedding_dim"] = dim
            memory["_embedding_dtype"] = dtype
        return memory

    def _row_to_retrieval_candidate(self, row: sqlite3.Row) -> Dict[str, Any]:
        """Build the private lean record used only while retrieval ranks candidates."""

        memory: Dict[str, Any] = {
            "id": row["id"],
            "text": row["text"],
            "type": row["type"],
            "stream": row["stream"],
            "ts": row["ts"],
            "session_id": row["session_id"],
            "turn": row["turn"],
            "scene_id": row["scene_id"],
            "source_event_ids": json.loads(row["source_event_ids_json"] or "[]"),
            "source_type": row["source_type"],
            "source_reliability": float(row["source_reliability"]),
            "verification_status": row["verification_status"],
            "fallback_generated": bool(row["fallback_generated"]),
            "speaker_focus": row["speaker_focus"],
            "memory_kind": row["memory_kind"],
            **{field: row[field] for field in _MEMORY_OPTIONAL_FIELDS},
            "embedding": None,
            "_embedding_blob": row["embedding_blob"],
            "_embedding_dim": row["embedding_dim"],
            "_embedding_dtype": row["embedding_dtype"],
            _RETRIEVAL_REPOSITORY_KEY: self,
        }
        memory["memory_kind"] = _normalize_memory_kind(memory)
        return memory

    def append_memories(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        return self._append_memories(records, preserve_ids=False)

    def _import_memories(self, records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Import historical IDs without consolidating existing evidence pointers."""

        return self._append_memories(records, preserve_ids=True)

    def _append_memories(
        self, records: List[Dict[str, Any]], *, preserve_ids: bool,
    ) -> List[Dict[str, Any]]:
        if not records:
            return []

        sql = """
        INSERT INTO memories (
            id, session_id, turn, scene_id, idx, text, type, stream, ts, source_type,
            source_reliability, verification_status, fallback_generated,
            source_event_ids_json, provenance_user, provenance_assistant, speaker_focus, memory_kind,
            event_date, event_start, event_end, subject, scope, attribute,
            correction_target, correction_evidence,
            h, tau, outgoing_weights, incoming_weights,
            embedding_blob, embedding_dim, embedding_dtype
        )
        VALUES (
            :id, :session_id, :turn, :scene_id, :idx, :text, :type, :stream, :ts, :source_type,
            :source_reliability, :verification_status, :fallback_generated,
            :source_event_ids_json, :provenance_user, :provenance_assistant, :speaker_focus, :memory_kind,
            :event_date, :event_start, :event_end, :subject, :scope, :attribute,
            :correction_target, :correction_evidence,
            :h, :tau, :outgoing_weights, :incoming_weights,
            :embedding_blob, :embedding_dim, :embedding_dtype
        )
        """
        rows = [self._record_to_row(record) for record in records]
        normalized_records = [_normalize_memory(record) for record in records]
        with self._lock, self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                memory_ids = list(dict.fromkeys(row["id"] for row in rows))
                placeholders = ",".join("?" for _ in memory_ids)
                existing_rows = (
                    conn.execute(
                        f"SELECT * FROM memories WHERE id IN ({placeholders})",
                        memory_ids,
                    ).fetchall()
                    if memory_ids
                    else []
                )
                existing = {
                    row["id"]: self._row_to_memory(row, decode_embedding=True)
                    for row in existing_rows
                }
                pending: Dict[str, Dict[str, Any]] = {}
                pending_order: List[str] = []
                for normalized, row in zip(normalized_records, rows):
                    memory_id = row["id"]
                    current = pending.get(memory_id, existing.get(memory_id))
                    if current is None:
                        pending[memory_id] = normalized
                        pending_order.append(memory_id)
                        continue
                    if _same_memory(current, normalized):
                        continue
                    _reject_memory_collision(memory_id)

                # Check exact evidence retries under the same write transaction
                # as immutable-ID validation. Independent processes cannot race
                # a fresh turn/id for an already persisted claim into the store.
                canonical_ids = {memory_id: memory_id for memory_id in existing}
                evidence_ids: Dict[str, str] = {}
                evidence_scopes = {
                    (str(record.get("session_id") or ""), record.get("scene_id"))
                    for record in pending.values()
                    if not preserve_ids and (record.get("scene_id") or record.get("source_event_ids"))
                }
                for session_id, scene_id in evidence_scopes:
                    candidate_rows = conn.execute(
                        "SELECT * FROM memories WHERE session_id = ? AND scene_id IS ?",
                        (session_id, scene_id),
                    ).fetchall()
                    for candidate in candidate_rows:
                        key = _exact_evidence_key(self._row_to_memory(candidate, decode_embedding=False))
                        if key is not None:
                            evidence_ids.setdefault(key, candidate["id"])

                inserted_rows = []
                for memory_id in pending_order:
                    record = pending[memory_id]
                    key = None if preserve_ids else _exact_evidence_key(record)
                    if key is not None:
                        if key in evidence_ids:
                            canonical_ids[memory_id] = evidence_ids[key]
                            continue
                        evidence_ids[key] = memory_id
                    canonical_ids[memory_id] = memory_id
                    inserted_rows.append(self._record_to_row(record))
                if inserted_rows:
                    conn.executemany(
                        sql,
                        inserted_rows,
                    )
                persisted_ids = list(dict.fromkeys(canonical_ids.values()))
                placeholders = ",".join("?" for _ in persisted_ids)
                persisted_rows = conn.execute(
                    f"SELECT * FROM memories WHERE id IN ({placeholders})", persisted_ids,
                ).fetchall()
                persisted = {
                    row["id"]: self._row_to_memory(row, decode_embedding=True)
                    for row in persisted_rows
                }
                accepted = [persisted[canonical_ids[row["id"]]] for row in rows]
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        return accepted

    def load_all_memories(self) -> List[Dict[str, Any]]:
        query = "SELECT * FROM memories ORDER BY ts ASC"
        with self._lock, self._connect() as conn:
            rows = conn.execute(query).fetchall()
        return [self._row_to_memory(row, decode_embedding=True) for row in rows]

    def get_recent_memories(self, limit: Optional[int] = 8, session_id: Optional[str] = None) -> List[Dict[str, Any]]:
        where = ""
        params: List[Any] = []
        if session_id:
            where = "WHERE session_id = ?"
            params.append(session_id)

        query = f"SELECT * FROM memories {where} ORDER BY ts DESC"
        if limit is not None:
            query += " LIMIT ?"
            params.append(int(limit))
        with self._lock, self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [self._row_to_memory(row, decode_embedding=True) for row in rows]

    def get_memory_count(self, session_id: Optional[str] = None) -> int:
        where = ""
        params: List[Any] = []
        if session_id:
            where = "WHERE session_id = ?"
            params.append(session_id)
        query = f"SELECT COUNT(*) AS c FROM memories {where}"
        with self._lock, self._connect() as conn:
            row = conn.execute(query, params).fetchone()
        return int(row["c"] if row else 0)

    def list_memory_session_ids(self, limit: int = 100) -> List[str]:
        query = "SELECT DISTINCT session_id FROM memories ORDER BY ts DESC LIMIT ?"
        with self._lock, self._connect() as conn:
            rows = conn.execute(query, (int(limit),)).fetchall()
        return [row["session_id"] for row in rows if row["session_id"]]

    def _filtered_rows(
        self,
        filters: CandidateFilters,
        session_id: Optional[str] = None,
        fts_rowids: Optional[set[int]] = None,
        *,
        retrieval_projection: bool = False,
    ) -> List[sqlite3.Row]:
        clauses = ["source_reliability >= ?"]
        params: List[Any] = [float(filters.min_reliability)]

        if filters.recency_days:
            cutoff = datetime.now(timezone.utc) - timedelta(days=filters.recency_days)
            clauses.append("ts >= ?")
            params.append(cutoff.isoformat())

        if filters.date_from:
            clauses.append("ts >= ?")
            params.append(filters.date_from)

        if filters.date_to:
            clauses.append("ts <= ?")
            params.append(filters.date_to)

        if filters.memory_types:
            placeholders = ",".join("?" for _ in filters.memory_types)
            clauses.append(f"LOWER(COALESCE(type, '')) IN ({placeholders})")
            params.extend([item.lower() for item in filters.memory_types])

        if filters.mode in {"rough", "learnings"}:
            clauses.append("stream = ?")
            params.append(filters.mode)

        if session_id:
            clauses.append("session_id = ?")
            params.append(session_id)

        where = " AND ".join(clauses) if clauses else "1=1"

        if fts_rowids is not None:
            if not fts_rowids:
                return []
            placeholders = ",".join("?" for _ in fts_rowids)
            where = f"({where}) AND rowid IN ({placeholders})"
            params.extend(list(fts_rowids))

        with self._lock, self._connect() as conn:
            projection = "*"
            if retrieval_projection:
                columns = {
                    str(row["name"])
                    for row in conn.execute("PRAGMA table_info(memories)").fetchall()
                }
                optional = {
                    "scene_id": "NULL",
                    "speaker_focus": "NULL",
                    "memory_kind": "NULL",
                    **{field: "NULL" for field in _MEMORY_OPTIONAL_FIELDS},
                }
                projected = [
                    "id",
                    "text",
                    "type",
                    "stream",
                    "ts",
                    "session_id",
                    "turn",
                    *[
                        name if name in columns else f"{fallback} AS {name}"
                        for name, fallback in optional.items()
                    ],
                    "source_event_ids_json",
                    "source_type",
                    "source_reliability",
                    "verification_status",
                    "fallback_generated",
                    "embedding_blob",
                    "embedding_dim",
                    "embedding_dtype",
                ]
                projection = ", ".join(projected)
            query = f"SELECT {projection} FROM memories WHERE {where} ORDER BY ts DESC"
            return conn.execute(query, params).fetchall()

    def query_candidates(self, filters: CandidateFilters) -> List[Dict[str, Any]]:
        if filters.session_id and filters.session_bias:
            rows = self._filtered_rows(filters, session_id=filters.session_id)
            if not rows:
                rows = self._filtered_rows(filters, session_id=None)
        else:
            rows = self._filtered_rows(filters, session_id=None)
        return [self._row_to_memory(row, decode_embedding=False, include_blob=True) for row in rows]

    def _query_retrieval_candidates(self, filters: CandidateFilters) -> List[Dict[str, Any]]:
        if filters.session_id and filters.session_bias:
            rows = self._filtered_rows(
                filters,
                session_id=filters.session_id,
                retrieval_projection=True,
            )
            if not rows:
                rows = self._filtered_rows(filters, session_id=None, retrieval_projection=True)
        else:
            rows = self._filtered_rows(filters, session_id=None, retrieval_projection=True)
        return [self._row_to_retrieval_candidate(row) for row in rows]

    def _fts5_search(self, fts_query: str) -> Optional[set[int]]:
        try:
            with self._lock, self._connect() as conn:
                rows = conn.execute(
                    "SELECT rowid FROM memories_fts WHERE memories_fts MATCH ?",
                    (fts_query,),
                ).fetchall()
                return {int(r["rowid"]) for r in rows}
        except sqlite3.OperationalError:
            return None

    def query_candidates_with_text(self, fts_query: str, filters: CandidateFilters) -> List[Dict[str, Any]]:
        if not fts_query or not fts_query.strip():
            return self.query_candidates(filters)
        fts_rowids = self._fts5_search(fts_query)
        if fts_rowids is not None:
            if filters.session_id and filters.session_bias:
                rows = self._filtered_rows(filters, session_id=filters.session_id, fts_rowids=fts_rowids)
                if not rows:
                    rows = self._filtered_rows(filters, session_id=None, fts_rowids=fts_rowids)
            else:
                rows = self._filtered_rows(filters, session_id=None, fts_rowids=fts_rowids)
            if rows:
                return [self._row_to_memory(row, decode_embedding=False, include_blob=True) for row in rows]
        return self.query_candidates(filters)

    def _query_retrieval_candidates_with_text(
        self,
        fts_query: str,
        filters: CandidateFilters,
    ) -> List[Dict[str, Any]]:
        if not fts_query or not fts_query.strip():
            return self._query_retrieval_candidates(filters)
        fts_rowids = self._fts5_search(fts_query)
        if fts_rowids is not None:
            if filters.session_id and filters.session_bias:
                rows = self._filtered_rows(
                    filters,
                    session_id=filters.session_id,
                    fts_rowids=fts_rowids,
                    retrieval_projection=True,
                )
                if not rows:
                    rows = self._filtered_rows(
                        filters,
                        session_id=None,
                        fts_rowids=fts_rowids,
                        retrieval_projection=True,
                    )
            else:
                rows = self._filtered_rows(
                    filters,
                    session_id=None,
                    fts_rowids=fts_rowids,
                    retrieval_projection=True,
                )
            if rows:
                return [self._row_to_retrieval_candidate(row) for row in rows]
        return self._query_retrieval_candidates(filters)

    def _hydrate_retrieval_candidates(self, memory_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """Restore the historical SQLite candidate shape for selected winners."""

        if not memory_ids:
            return {}
        unique_ids = list(dict.fromkeys(memory_ids))
        placeholders = ",".join("?" for _ in unique_ids)
        query = f"SELECT * FROM memories WHERE id IN ({placeholders})"
        with self._lock, self._connect() as conn:
            rows = conn.execute(query, unique_ids).fetchall()
        return {
            row["id"]: self._row_to_memory(row, decode_embedding=False, include_blob=True)
            for row in rows
        }

    def query_by_ids(self, memory_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        if not memory_ids:
            return {}
        placeholders = ",".join("?" for _ in memory_ids)
        query = f"SELECT * FROM memories WHERE id IN ({placeholders})"
        with self._lock, self._connect() as conn:
            rows = conn.execute(query, memory_ids).fetchall()
        result: Dict[str, Dict[str, Any]] = {}
        for row in rows:
            record = self._row_to_memory(row, decode_embedding=True, include_blob=True)
            result[row["id"]] = record
        return result

def get_memory_repository() -> MemoryStore:
    global _REPO_CACHE, _REPO_CACHE_KEY

    _refresh_json_paths()
    backend = _resolve_backend()
    sqlite_path = _resolve_sqlite_path()
    cache_key = (backend, str(sqlite_path))
    if _REPO_CACHE is not None and _REPO_CACHE_KEY == cache_key:
        return _REPO_CACHE

    if backend == "json":
        _REPO_CACHE = JsonMemoryRepository()
        _REPO_CACHE_KEY = cache_key
        return _REPO_CACHE

    # Backend choice is a write contract. An unavailable configured SQLite
    # store must fail visibly rather than silently splitting writes into JSON.
    # Legacy JSON remains available by explicitly selecting that backend.
    _REPO_CACHE = SqliteMemoryRepository(sqlite_path)
    _REPO_CACHE_KEY = cache_key
    return _REPO_CACHE


_REAL_GET_MEMORY_REPOSITORY = get_memory_repository


def load_all_memories() -> List[Dict[str, Any]]:
    LOGGER.warning(
        "load_all_memories() loads the full memory store into RAM; prefer repository.query_candidates() for retrieval paths."
    )
    return get_memory_repository().load_all_memories()


def save_all_memories(memories: List[Dict[str, Any]]) -> None:
    repo = get_memory_repository()
    if isinstance(repo, JsonMemoryRepository):
        repo.save_all_memories(memories)
        return

    # SQLite-backed stores do not support bulk replacement safely in place.
    LOGGER.warning("save_all_memories() is JSON-only. Skipping operation for backend '%s'.", _resolve_backend())


def append_memories(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return get_memory_repository().append_memories(records)


def create_memory_record(
    session_id: str,
    turn: int,
    index: int,
    text: str,
    user_text: str,
    assistant_text: str,
    scene_id: Optional[str] = None,
    memory_type: Optional[str] = None,
    stream: str = "rough",
    embedding: Optional[List[float]] = None,
    source_event_ids: Optional[List[str]] = None,
    source_type: str = "unknown",
    source_reliability: float = 0.5,
    verification_status: str = "unverified",
    fallback_generated: bool = False,
    speaker_focus: Optional[str] = None,
    memory_kind: Optional[str] = None,
) -> Dict[str, Any]:
    return {
        "id": f"{session_id}:{turn}:{index}",
        "text": text,
        "type": memory_type,
        "stream": stream,
        "embedding": embedding,
        "ts": now_iso(),
        "session_id": session_id,
        "turn": turn,
        "scene_id": scene_id,
        "provenance": {"user": user_text, "assistant": assistant_text},
        "source_event_ids": list(source_event_ids or []),
        "source_type": source_type,
        "source_reliability": source_reliability,
        "verification_status": verification_status,
        "fallback_generated": bool(fallback_generated),
        "speaker_focus": speaker_focus,
        "memory_kind": memory_kind,
    }


def get_memories_for_session(session_id: str) -> List[Memory]:
    all_memories = get_memory_repository().load_all_memories()
    session_memories = [Memory(**_normalize_memory(mem)) for mem in all_memories if mem.get("session_id") == session_id]
    return session_memories


def get_recent_memories(
    limit: Optional[int] = 8,
    session_id: Optional[str] = None,
    sources: Optional[list[str] | tuple[str, ...] | str] = None,
) -> List[Memory]:
    # Recall is federated by default for every agent. This call stays read-only
    # and passes explicit repositories into the federation seam.
    try:
        from app.runtime.context import get_runtime_context
        active_agent = get_runtime_context().agent_name
    except Exception:
        active_agent = "default"
    # Resolve the active repository here so dependency overrides and test
    # doubles on this module remain authoritative. Foreign-only selections do
    # not need (or create) the active store.
    from app.retrieval_pipeline.federated import get_federated_recall

    source_probe = get_federated_recall(active_agent=active_agent)
    selected_sources = source_probe.sources(sources)
    active_repositories = {}
    storage_repository_is_default = get_memory_repository is _REAL_GET_MEMORY_REPOSITORY
    effective_sources = selected_sources if sources is None else sources
    if sources is None and not storage_repository_is_default:
        # An injected repository is an explicit local dependency. Keep tests
        # and isolated callers away from ambient agent workspaces unless they
        # request federation explicitly.
        selected_sources = [active_agent]
        effective_sources = selected_sources
    if active_agent in selected_sources:
        active_repositories[active_agent] = get_memory_repository()
    recall = get_federated_recall(
        active_agent=active_agent,
        memory_repositories=active_repositories,
        include_active_buffer=(
            active_agent in selected_sources
            and storage_repository_is_default
        ),
    )
    records = recall.get_recent_memories(
        limit=limit, session_id=session_id, sources=effective_sources
    )
    return [Memory(**_normalize_memory(record)) for record in records]


def get_memory_count(session_id: Optional[str] = None) -> int:
    return get_memory_repository().get_memory_count(session_id=session_id)


def list_memory_session_ids(limit: int = 100) -> list[str]:
    return get_memory_repository().list_memory_session_ids(limit=limit)


def migrate_legacy_memories() -> int:
    """
    Add source and stream fields to legacy JSON memories created before v2.
    This migration intentionally targets memories.json for backward compatibility.
    """
    _refresh_json_paths()
    all_memories = read_json(MEMORIES_FILE, [])
    migrated = 0
    for mem in all_memories:
        changed = False
        if "source_type" not in mem:
            mem["source_type"] = "legacy"
            mem["source_reliability"] = 0.3
            mem["verification_status"] = "unverified"
            changed = True
        if "stream" not in mem:
            mem["stream"] = "rough"
            changed = True
        if "source_event_ids" not in mem:
            mem["source_event_ids"] = []
            changed = True
        if changed:
            migrated += 1

    if migrated > 0:
        write_json(MEMORIES_FILE, all_memories)
    return migrated


def query_memory_candidates(
    filters: CandidateFilters,
    *,
    _retrieval_projection: bool = False,
) -> List[Dict[str, Any]]:
    repository = get_memory_repository()
    if _retrieval_projection:
        query = getattr(repository, "_query_retrieval_candidates", None)
        if callable(query):
            return query(filters)
    return repository.query_candidates(filters)


def query_memory_candidates_with_text(
    fts_query: str,
    filters: CandidateFilters,
    *,
    _retrieval_projection: bool = False,
) -> List[Dict[str, Any]]:
    repository = get_memory_repository()
    if _retrieval_projection:
        query = getattr(repository, "_query_retrieval_candidates_with_text", None)
        if callable(query):
            return query(fts_query, filters)
    return repository.query_candidates_with_text(fts_query, filters)


def migrate_json_to_sqlite(sqlite_path: Optional[Path] = None) -> Dict[str, Any]:
    _refresh_json_paths()
    started_at = datetime.now(timezone.utc)
    source = read_json(MEMORIES_FILE, [])
    db_path = sqlite_path or _resolve_sqlite_path()
    repo = SqliteMemoryRepository(db_path)

    skipped = 0
    normalized_records: List[Dict[str, Any]] = []

    with repo._lock, repo._connect() as conn:
        existing_ids = {row["id"] for row in conn.execute("SELECT id FROM memories").fetchall()}

    for mem in source:
        normalized = _normalize_memory(mem)
        memory_id = str(normalized.get("id") or "")
        if not memory_id:
            skipped += 1
            continue
        normalized_records.append(normalized)

    try:
        normalized_records = repo._import_memories(normalized_records)
    except Exception:
        # Fall back to per-record writes so malformed rows do not block migration.
        saved_records: List[Dict[str, Any]] = []
        for record in normalized_records:
            try:
                saved_records.extend(repo._import_memories([record]))
            except Exception:
                skipped += 1
        normalized_records = saved_records

    migrated_ids = {str(record.get("id")) for record in normalized_records}
    updated = len(migrated_ids & existing_ids)
    inserted = len(migrated_ids - existing_ids)

    duration_ms = int((datetime.now(timezone.utc) - started_at).total_seconds() * 1000)
    report = {
        "source_count": len(source),
        "inserted": inserted,
        "updated": updated,
        "skipped": skipped,
        "duration_ms": duration_ms,
        "sqlite_path": str(db_path),
    }
    return report
