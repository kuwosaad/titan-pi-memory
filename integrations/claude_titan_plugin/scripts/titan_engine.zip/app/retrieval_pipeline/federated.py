"""Read-only recall across isolated Titan agent namespaces.

Federation is deliberately a read seam.  Each namespace is queried through
the normal repository adapter and the normal retrieval engine; no runtime
environment is changed while another namespace is being inspected.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import logging
import re
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence

from app.storage.memories import JsonMemoryRepository, SqliteMemoryRepository, get_memory_repository
from app.storage.repository import MemoryStore
from app.storage.scenes import JsonSceneRepository, SceneRepository, SqliteSceneRepository, get_scene_repository


_AGENT_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
LOGGER = logging.getLogger(__name__)
_MAX_EVIDENCE_REFS = 10


def _validate_agent_name(agent_name: str) -> str:
    value = str(agent_name or "").strip()
    if not _AGENT_NAME_RE.fullmatch(value):
        raise ValueError("invalid agent namespace")
    return value


def namespace_memory_db_path(agent_name: str, titan_home: Optional[Path] = None) -> Path:
    """Return the canonical DB path for an agent namespace."""

    safe_agent = _validate_agent_name(agent_name)
    titan_root = (titan_home or (Path.home() / ".titan")).expanduser().resolve()
    root = (titan_root / "agents" / safe_agent).resolve()
    expected_parent = (titan_root / "agents").resolve()
    if expected_parent not in root.parents:
        raise ValueError("agent namespace escaped Titan home")
    return root / "out" / "memories" / "memory_store.db"


def discover_agent_namespaces(titan_home: Optional[Path] = None) -> list[str]:
    """Return valid agent workspaces from the shared Titan home."""

    agents_dir = (titan_home or (Path.home() / ".titan")) / "agents"
    if not agents_dir.is_dir():
        return []
    try:
        return [
            path.name
            for path in sorted(agents_dir.iterdir())
            if path.is_dir() and _AGENT_NAME_RE.fullmatch(path.name)
        ]
    except OSError:
        return []


def _scene_json_path_for_db(db_path: Path) -> Path:
    return db_path.with_name("scenes.json")


def _memory_repository_for_path(path: Path) -> Optional[MemoryStore]:
    if path.suffix.lower() == ".json":
        return JsonMemoryRepository(path) if path.exists() else None
    if path.exists():
        return SqliteMemoryRepository(path, initialize=False)
    json_path = path.with_name("memories.json")
    return JsonMemoryRepository(json_path) if json_path.exists() else None


def _scene_repository_for_path(path: Path) -> Optional[SceneRepository]:
    if path.suffix.lower() == ".json":
        return JsonSceneRepository(path) if path.exists() else None
    if path.exists():
        return SqliteSceneRepository(path, initialize=False)
    json_path = _scene_json_path_for_db(path)
    return JsonSceneRepository(json_path) if json_path.exists() else None


def _source_list(active_agent: str, sources: Optional[Sequence[str] | str]) -> list[str]:
    if sources is None:
        selected = [active_agent]
    elif isinstance(sources, str):
        raw = sources.strip()
        if raw.startswith("["):
            loaded = json.loads(raw)
            if not isinstance(loaded, list):
                raise ValueError("sources must be a list")
            selected = [str(source).strip() for source in loaded if str(source).strip()]
        else:
            selected = [part.strip() for part in re.split(r"[,\n]", raw) if part.strip()]
    else:
        selected = [str(source).strip() for source in sources if str(source).strip()]
    result: list[str] = []
    for source in selected:
        if source not in result:
            result.append(source)
    return result


def _timestamp(value: Any) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return datetime.min.replace(tzinfo=timezone.utc)


def _normalized_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _identity(record: Mapping[str, Any]) -> tuple[str, str]:
    return (str(record.get("source_agent") or ""), str(record.get("id") or ""))


def _evidence_ref(record: Mapping[str, Any]) -> tuple[str, str, str]:
    return (*_identity(record), str(record.get("scene_id") or ""))


def _display_group_key(record: Mapping[str, Any]) -> tuple[str, ...]:
    # Case and internal whitespace can carry meaning in paths, identifiers,
    # and string literals. Explicit scope is also part of the claim.
    scope_fields = ("scope", "project", "project_id", "project_path", "repository", "entity_id", "subject")
    return (str(record.get("text") or "").strip(), *(
        json.dumps(record.get(field), sort_keys=True, default=str) for field in scope_fields
    ))


def _qualify_evidence(record: Mapping[str, Any], source_agent: str) -> dict[str, Any]:
    result = {**record, "source_agent": source_agent}
    if record.get("evidence_refs"):
        result["evidence_refs"] = [
            {**ref, "source_agent": ref.get("source_agent") or source_agent}
            for ref in record["evidence_refs"] if isinstance(ref, Mapping)
        ]
    return result


def _with_duplicate_evidence(winner: dict[str, Any], records: list[dict[str, Any]]) -> dict[str, Any]:
    """Union inherited pointers before bounding the identical-text display group."""
    winner_ref = _evidence_ref(winner)
    references = {_evidence_ref(record) for record in records}
    truncated = any(bool(record.get("evidence_refs_truncated")) for record in records)
    for record in records:
        for ref in record.get("evidence_refs") or []:
            if isinstance(ref, Mapping) and ref.get("memory_id"):
                references.add((str(ref.get("source_agent") or record.get("source_agent") or ""),
                                str(ref["memory_id"]), str(ref.get("scene_id") or "")))
    references = {ref for ref in references if ref[1] or ref[2]}
    if len(references) < 2 and not truncated:
        return winner
    ordered = ([winner_ref] if winner_ref in references else []) + sorted(references - {winner_ref})
    result = dict(winner)
    result["evidence_refs"] = [
        {"source_agent": source, "memory_id": memory_id, **({"scene_id": scene_id} if scene_id else {})}
        for source, memory_id, scene_id in ordered[:_MAX_EVIDENCE_REFS]
    ]
    if truncated or len(ordered) > _MAX_EVIDENCE_REFS:
        result["evidence_refs_truncated"] = True
    return result


def _rank_score(hit: Mapping[str, Any]) -> float:
    for field in ("selection_score", "score", "final_score"):
        if hit.get(field) is not None:
            return float(hit[field])
    return 0.0


class FederatedRecall:
    """One explicit, read-only seam for multi-agent memory and scene recall."""

    def __init__(
        self,
        *,
        active_agent: str = "codex",
        memory_repositories: Optional[Mapping[str, MemoryStore]] = None,
        scene_repositories: Optional[Mapping[str, SceneRepository]] = None,
        memory_paths: Optional[Mapping[str, Path]] = None,
        scene_paths: Optional[Mapping[str, Path]] = None,
        titan_home: Optional[Path] = None,
        federation_root: Optional[Path] = None,
        include_active_buffer: Optional[bool] = None,
    ) -> None:
        self.active_agent = str(active_agent or "codex")
        self._memory_repositories = dict(memory_repositories or {})
        self._scene_repositories = dict(scene_repositories or {})
        self._memory_paths = {str(key): Path(value) for key, value in (memory_paths or {}).items()}
        self._scene_paths = {str(key): Path(value) for key, value in (scene_paths or {}).items()}
        self._titan_home = titan_home
        self._federation_root = federation_root or titan_home
        self._include_active_buffer = include_active_buffer

    def sources(self, sources: Optional[Sequence[str] | str] = None) -> list[str]:
        selected = _source_list(self.active_agent, sources)
        if sources is None:
            known_sources = (
                list(self._memory_repositories)
                + list(self._scene_repositories)
                + list(self._memory_paths)
                + list(self._scene_paths)
            )
            discovered_sources: list[str] = []
            if not known_sources:
                discovered_sources = discover_agent_namespaces(self._federation_root)
            for source in known_sources + discovered_sources:
                if source not in selected:
                    selected.append(source)
        for source in selected:
            _validate_agent_name(source)
        return selected

    def _memory_repository(self, source_agent: str) -> Optional[MemoryStore]:
        if source_agent in self._memory_repositories:
            return self._memory_repositories[source_agent]
        if source_agent in self._memory_paths:
            repository = _memory_repository_for_path(self._memory_paths[source_agent])
            if repository is not None:
                self._memory_repositories[source_agent] = repository
            return repository
        # An explicit home is used for every namespace, including the active
        # one.  This keeps isolated/test recalls from reaching the process
        # global repository (which may create or touch its live store).
        if source_agent == self.active_agent and self._titan_home is None:
            return get_memory_repository()
        return _memory_repository_for_path(namespace_memory_db_path(source_agent, self._federation_root))

    def _scene_repository(self, source_agent: str) -> Optional[SceneRepository]:
        if source_agent in self._scene_repositories:
            return self._scene_repositories[source_agent]
        if source_agent in self._scene_paths:
            repository = _scene_repository_for_path(self._scene_paths[source_agent])
            if repository is not None:
                self._scene_repositories[source_agent] = repository
            return repository
        if source_agent == self.active_agent and self._titan_home is None:
            return get_scene_repository()
        return _scene_repository_for_path(namespace_memory_db_path(source_agent, self._federation_root))

    def get_recent_memories(
        self,
        *,
        limit: Optional[int] = 8,
        session_id: Optional[str] = None,
        sources: Optional[Sequence[str] | str] = None,
    ) -> list[dict[str, Any]]:
        if limit is not None and int(limit) <= 0:
            return []
        selected = self.sources(sources)
        records: list[dict[str, Any]] = []
        for source_agent in selected:
            try:
                repository = self._memory_repository(source_agent)
                if repository is None:
                    continue
                source_records = repository.get_recent_memories(limit=limit, session_id=session_id)
            except Exception as exc:
                if source_agent == self.active_agent:
                    raise
                LOGGER.warning("Skipping unreadable Titan namespace %s: %s", source_agent, exc)
                continue
            for record in source_records:
                item = dict(record)
                item["source_agent"] = source_agent
                records.append(item)

        # The active namespace may have freshly captured records waiting for
        # the dedup worker.  Keep the historical recent-memory behavior for
        # that namespace, while never treating the active process buffer as a
        # record from an explicitly requested foreign source.
        use_live_active_buffer = (
            self.active_agent in selected
            and self._titan_home is None
            and (
                self._include_active_buffer
                if self._include_active_buffer is not None
                else (
                    self.active_agent not in self._memory_repositories
                    and self.active_agent not in self._memory_paths
                )
            )
        )
        if use_live_active_buffer:
            try:
                from app.save_pipeline.dedup_buffer import peek_dedup_buffer

                buffer_limit = max((limit // 2) if limit is not None else 100, 2)
                buffered = peek_dedup_buffer(limit=buffer_limit, session_id=session_id)
                for record in buffered:
                    item = dict(record)
                    item.pop("_buffer_ts", None)
                    item["source_agent"] = self.active_agent
                    records.append(item)
            except Exception:
                # A transient/corrupt optional buffer must not make durable
                # namespace recall unavailable.
                pass

        return self._merge_records(records, limit)

    def query_memories(
        self,
        query: str,
        *,
        session_id: Optional[str] = None,
        limit: int = 8,
        mode: Optional[str] = None,
        sources: Optional[Sequence[str] | str] = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        return [dict(hit.get("memory") or {}) for hit in self.query_hits(
            query,
            session_id=session_id,
            limit=limit,
            mode=mode,
            sources=sources,
            **kwargs,
        )]

    def query_hits(
        self,
        query: str,
        *,
        session_id: Optional[str] = None,
        limit: int = 8,
        mode: Optional[str] = None,
        sources: Optional[Sequence[str] | str] = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        from app.embedding.embedder import query_embedding_reuse_scope
        from app.retrieval_pipeline.retriever import retrieve_memories, _source_passage_hits, _combine_source_hits

        if int(limit) <= 0:
            return []
        selected = self.sources(sources)
        hits: list[dict[str, Any]] = []
        with query_embedding_reuse_scope():
            for source_agent in selected:
                try:
                    repository = self._memory_repository(source_agent)
                    scene_repository = self._scene_repository(source_agent)
                    if repository is None and not callable(getattr(scene_repository, "get_recent_scenes", None)):
                        continue
                    # Never substitute the active namespace's memory store for
                    # a missing foreign store.
                    if repository is None:
                        source_hits = _source_passage_hits(
                            query, scene_repository, source_agent, limit=int(limit),
                            session_id=session_id, mode=mode or "both", **{
                                key: kwargs[key] for key in (
                                    "memory_types", "date_from", "date_to", "date_basis",
                                    "min_similarity", "min_reliability", "include_source_passages",
                                ) if key in kwargs
                            },
                        )
                    else:
                        source_hits = retrieve_memories(
                            query=query,
                            session_id=session_id,
                            top_k=limit,
                            mode=mode or "both",
                            repository=repository,
                            source_agent=source_agent,
                            scene_repository=scene_repository,
                            **kwargs,
                        )
                except Exception as exc:
                    if source_agent == self.active_agent:
                        raise
                    LOGGER.warning("Skipping unreadable Titan namespace %s: %s", source_agent, exc)
                    continue
                for hit in source_hits:
                    annotated = dict(hit)
                    memory = _qualify_evidence(hit.get("memory") or {}, source_agent)
                    annotated["memory"] = memory
                    annotated["source_agent"] = source_agent
                    hits.append(annotated)

        merged = self._merge_hits(hits, None)
        passages = [hit for hit in merged if (hit.get("memory") or {}).get("result_kind") == "source_passage"]
        merged = [hit for hit in merged if (hit.get("memory") or {}).get("result_kind") != "source_passage"]
        aspect_count = max((len(hit.get("query_aspects") or []) for hit in merged), default=0)
        if aspect_count > 1:
            from app.retrieval_pipeline.config import load_settings
            from app.retrieval_pipeline.retriever import _select_diverse_hits

            selection = load_settings().get("retrieval_selection", {}) or {}
            if selection.get("enabled", False):
                # Apply the same facet allocation once across namespaces so a
                # scalar merge cannot consume every slot with one question.
                merged = _select_diverse_hits(merged, {}, int(limit), aspect_count, selection)
        return _combine_source_hits(merged, passages, int(limit))

    def _merge_records(self, records: list[dict[str, Any]], limit: Optional[int]) -> list[dict[str, Any]]:
        selected: dict[tuple[str, ...], dict[str, Any]] = {}
        groups: dict[tuple[str, ...], list[dict[str, Any]]] = {}
        for record in records:
            key = _display_group_key(record) if _normalized_text(record.get("text")) else ("id", *_identity(record))
            groups.setdefault(key, []).append(record)
            current = selected.get(key)
            if current is None or self._prefer(record, current):
                selected[key] = record
        merged = sorted(
            (_with_duplicate_evidence(record, groups[key]) for key, record in selected.items()),
            key=lambda item: (item.get("source_agent") != self.active_agent, _identity(item)),
        )
        merged.sort(key=lambda item: _timestamp(item.get("ts")), reverse=True)
        return merged if limit is None else merged[: max(0, int(limit))]

    def _merge_hits(self, hits: list[dict[str, Any]], limit: Optional[int]) -> list[dict[str, Any]]:
        selected: dict[tuple[str, ...], dict[str, Any]] = {}
        groups: dict[tuple[str, ...], list[dict[str, Any]]] = {}
        for hit in hits:
            memory = hit.get("memory") or {}
            if memory.get("result_kind") == "source_passage":
                key = ("source_passage", str(memory.get("source_agent") or ""),
                       *(str(event) for event in memory.get("source_event_ids") or []))
            else:
                key = ("fact", *_display_group_key(memory)) if _normalized_text(memory.get("text")) else ("id", *_identity(memory))
            groups.setdefault(key, []).append(memory)
            current = selected.get(key)
            if current is None or self._prefer_hit(hit, current):
                selected[key] = hit
        merged = sorted((
            {**hit, "memory": _with_duplicate_evidence(hit.get("memory") or {}, groups[key])}
            for key, hit in selected.items()
        ), key=lambda item: (
            item.get("source_agent") != self.active_agent, _identity(item.get("memory") or {})
        ))
        merged.sort(
            key=lambda item: (_rank_score(item), _timestamp((item.get("memory") or {}).get("ts"))),
            reverse=True,
        )
        return merged if limit is None else merged[: max(0, int(limit))]

    def _prefer(self, candidate: dict[str, Any], current: dict[str, Any]) -> bool:
        candidate_active = candidate.get("source_agent") == self.active_agent
        current_active = current.get("source_agent") == self.active_agent
        if candidate_active != current_active:
            return candidate_active
        candidate_time = _timestamp(candidate.get("ts"))
        current_time = _timestamp(current.get("ts"))
        return candidate_time > current_time or (candidate_time == current_time and _identity(candidate) < _identity(current))

    def _prefer_hit(self, candidate: dict[str, Any], current: dict[str, Any]) -> bool:
        candidate_active = candidate.get("source_agent") == self.active_agent
        current_active = current.get("source_agent") == self.active_agent
        if candidate_active != current_active:
            return candidate_active
        candidate_score = _rank_score(candidate)
        current_score = _rank_score(current)
        if candidate_score != current_score:
            return candidate_score > current_score
        candidate_memory = candidate.get("memory") or {}
        current_memory = current.get("memory") or {}
        candidate_time = _timestamp(candidate_memory.get("ts"))
        current_time = _timestamp(current_memory.get("ts"))
        return candidate_time > current_time or (candidate_time == current_time and _identity(candidate_memory) < _identity(current_memory))

    def scene_references(
        self,
        memories: Sequence[Mapping[str, Any]],
        *,
        sources: Optional[Sequence[str] | str] = None,
    ) -> list[dict[str, Any]]:
        grouped: dict[str, list[str]] = {}
        order: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        allowed = set(self.sources(sources))
        for memory in memories:
            source_agent = str(memory.get("source_agent") or self.active_agent)
            pointers = [{"source_agent": source_agent, "scene_id": memory.get("scene_id")},
                        *(memory.get("evidence_refs") or [])]
            for pointer in pointers:
                if not isinstance(pointer, Mapping):
                    continue
                scene_id = str(pointer.get("scene_id") or "").strip()
                source = str(pointer.get("source_agent") or source_agent)
                if not scene_id or source not in allowed:
                    continue
                identity = (source, scene_id)
                if identity in seen:
                    continue
                seen.add(identity)
                order.append(identity)
                grouped.setdefault(source, []).append(scene_id)

        references: dict[tuple[str, str], dict[str, Any]] = {}
        failed: set[tuple[str, str]] = set()
        for source_agent, scene_ids in grouped.items():
            try:
                repository = self._scene_repository(source_agent)
            except Exception:
                failed.update((source_agent, scene_id) for scene_id in scene_ids)
                continue
            if repository is None:
                continue
            try:
                refs = repository.get_scene_references(scene_ids)
            except Exception:
                refs = []
                for scene_id in scene_ids:
                    try:
                        refs.extend(repository.get_scene_references([scene_id]))
                    except Exception:
                        failed.add((source_agent, scene_id))
                        continue
            for reference in refs:
                scene_id = str(reference.get("scene_id") or "").strip()
                identity = (source_agent, scene_id)
                if identity not in seen:
                    continue
                item = dict(reference)
                item["source_agent"] = source_agent
                references.setdefault(identity, item)
        return [
            references.get(identity) or {
                "source_agent": identity[0],
                "scene_id": identity[1],
                "scene_available": None if identity in failed else False,
                "evidence_status": "partial",
            }
            for identity in order
        ]

    def get_scene_context(self, scene_id: str, *, source_agent: Optional[str] = None) -> dict[str, Any]:
        normalized_scene_id = str(scene_id or "").strip()
        if not normalized_scene_id:
            return {"error": "scene_id is required", "scene_id": normalized_scene_id}
        source = _validate_agent_name(str(source_agent or self.active_agent))
        repository = self._scene_repository(source)
        scene = repository.get_scene(normalized_scene_id) if repository is not None else None
        if not scene:
            return {"error": "scene not found", "scene_id": normalized_scene_id}
        payload = dict(scene)
        payload["source_agent"] = source
        return {"scene": payload}


def get_federated_recall(**kwargs: Any) -> FederatedRecall:
    if "active_agent" not in kwargs or "federation_root" not in kwargs:
        from app.runtime.context import get_runtime_context

        context = get_runtime_context()
        kwargs.setdefault("active_agent", context.agent_name)
        shared_home = getattr(context, "shared_home", None)
        if not isinstance(shared_home, (str, Path)):
            shared_home = Path.home() / ".titan"
        kwargs.setdefault("federation_root", Path(shared_home))
    return FederatedRecall(**kwargs)
