"""Shared SQLite plumbing for the pattern adapters.

Keeping connection setup here prevents the API, bundle exporter, graph view,
and processing ledger from slowly acquiring different timeout/pragma behavior.
The schema itself remains owned by :mod:`app.storage.sqlite_schema`.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import ContextManager, Optional

from app.storage.memories import _resolve_sqlite_path
from app.storage.sqlite import sqlite_connection


def resolve_pattern_db_path() -> Path:
    """Return Titan's configured SQLite path (compatibility fallback included)."""

    return Path(_resolve_sqlite_path())


def connect_pattern_db(db_path: Optional[Path] = None) -> ContextManager[sqlite3.Connection]:
    """Return a transactional pattern connection that closes on exit."""

    path = Path(db_path) if db_path is not None else resolve_pattern_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    return sqlite_connection(path)
